package com.greatlearning.EmployeeManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
